<template>
  <section class="statistics-page">
    <h1 class="statistics-page__title">Welcome back, Agadil</h1>
  </section>
</template>

<script>
export default {

}
</script>

<style scoped></style>
