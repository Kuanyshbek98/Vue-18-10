<template>
  <div class="experts">
    <h2 class="experts__title">Experts with the highest rating in Clagme</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.experts {
  padding: 64px 0 72px;
}
.experts__title {
  font-size: 36px;
  line-height: 48px;
  margin: 0 0 32px;
  text-align: center;
}
</style>
