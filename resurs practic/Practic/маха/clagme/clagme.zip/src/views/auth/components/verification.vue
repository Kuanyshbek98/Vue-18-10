<template>
  <div class="verification auth">
    <h2 class="auth__title verification__title">Email Verification</h2>
    <p class="auth__text verification__text">
      We are delighted that you made the decision clagging with us. You will get
      a confirmation email with a verification code shortly.
    </p>
  </div>
</template>

<script>
export default {
  components: {},
};
</script>

<style scoped src="@/assets/css/auth.css"></style>

<style scoped>
.verification {
}
.verification__title {
  margin-top: 0;
}
</style>
