<template>
  <section class="statistics-page">
    <h1 class="statistics-page__title admin-title">Welcome back, Agadil</h1>
    <h2 class="statistics-page__subtitle"></h2>
  </section>
</template>

<script>
export default {

}
</script>

<style scoped>
.statistics-page__title {
  margin-bottom: 8px;
}
</style>
